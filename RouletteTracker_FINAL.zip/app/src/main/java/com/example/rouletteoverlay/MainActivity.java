package com.example.rouletteoverlay;

import android.app.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b); show();}
  void show(){
    LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(40,40,40,40);
    TextView t=new TextView(this); t.setText("Roulette Tracker"); t.setTextSize(24); t.setTextColor(Color.BLACK); l.addView(t);
    TextView info=new TextView(this); info.setText("Enable 'Display over other apps', then tap Start Overlay. The roulette tracker will float above other apps."); info.setTextSize(16); info.setPadding(0,24,0,24); l.addView(info);
    Button p=new Button(this); p.setText("Display over other apps"); p.setOnClickListener(v->{startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));}); l.addView(p);
    Button s=new Button(this); s.setText("Start Overlay"); s.setOnClickListener(v->{if(Settings.canDrawOverlays(this)){startForegroundService(new Intent(this,OverlayService.class)); finish();}else Toast.makeText(this,"Please allow Display over other apps first",Toast.LENGTH_LONG).show();}); l.addView(s);
    Button stop=new Button(this); stop.setText("Stop Overlay"); stop.setOnClickListener(v->stopService(new Intent(this,OverlayService.class))); l.addView(stop);
    setContentView(l);
  }
}
