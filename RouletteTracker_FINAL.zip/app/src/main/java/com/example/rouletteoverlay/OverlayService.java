package com.example.rouletteoverlay;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;

public class OverlayService extends Service {
  WindowManager wm;
  View root;
  WindowManager.LayoutParams params;
  float downX, downY;
  int startX, startY, startW, startH;

  @Override public void onCreate(){
    super.onCreate();
    String ch="roulette_tracker";
    if(Build.VERSION.SDK_INT>=26){
      NotificationChannel c=new NotificationChannel(ch,"Roulette Tracker",NotificationManager.IMPORTANCE_LOW);
      getSystemService(NotificationManager.class).createNotificationChannel(c);
    }
    Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ch):new Notification.Builder(this);
    nb.setContentTitle("Roulette Tracker").setContentText("Overlay is running")
      .setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true);
    startForeground(7,nb.build());

    WebView w=new WebView(this);
    w.setBackgroundColor(0xFF101010);
    w.getSettings().setJavaScriptEnabled(true);
    w.getSettings().setDomStorageEnabled(true);
    w.setWebChromeClient(new WebChromeClient());
    w.loadUrl("file:///android_asset/roulette_tracker.html");

    FrameLayout box=new FrameLayout(this);
    TextView bar=new TextView(this);
    bar.setText("  Roulette Tracker                                      ×");
    bar.setTextSize(16);
    bar.setTextColor(Color.WHITE);
    bar.setBackgroundColor(0xFF222222);
    bar.setGravity(Gravity.CENTER_VERTICAL);
    bar.setPadding(12,0,12,0);
    bar.setSingleLine(true);
    bar.setEllipsize(null);

    // Drag only from the title bar. The old code used both OnTouchListener
    // and OnClickListener, so the touch listener consumed the click and × did not work.
    bar.setOnTouchListener(new View.OnTouchListener(){
      boolean moved;
      @Override public boolean onTouch(View v, MotionEvent e){
        switch(e.getActionMasked()){
          case MotionEvent.ACTION_DOWN:
            downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; moved=false; return true;
          case MotionEvent.ACTION_MOVE:
            float dx=e.getRawX()-downX, dy=e.getRawY()-downY;
            if(Math.abs(dx)>6 || Math.abs(dy)>6) moved=true;
            if(moved){ params.x=startX+(int)dx; params.y=startY+(int)dy; wm.updateViewLayout(root,params); }
            return true;
          case MotionEvent.ACTION_UP:
            // × is a visual close button on the right side. A simple tap on the bar closes.
            if(!moved && e.getX()>v.getWidth()-70) stopSelf();
            return true;
        }
        return true;
      }
    });

    box.addView(w,new FrameLayout.LayoutParams(-1,-1));
    FrameLayout.LayoutParams barLp=new FrameLayout.LayoutParams(-1,50,Gravity.TOP);
    box.addView(bar,barLp);

    // Resize handle: drag the bottom-right corner to resize the overlay.
    TextView resize=new TextView(this);
    resize.setText("↘");
    resize.setTextSize(20);
    resize.setTextColor(0xFFFFFFFF);
    resize.setGravity(Gravity.CENTER);
    resize.setBackgroundColor(0xAA333333);
    FrameLayout.LayoutParams resizeLp=new FrameLayout.LayoutParams(42,42,Gravity.BOTTOM|Gravity.RIGHT);
    box.addView(resize,resizeLp);
    resize.setOnTouchListener((v,e)->{
      switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:
          downX=e.getRawX(); downY=e.getRawY(); startW=params.width; startH=params.height; return true;
        case MotionEvent.ACTION_MOVE:
          int newW=Math.max(300,startW+(int)(e.getRawX()-downX));
          int newH=Math.max(260,startH+(int)(e.getRawY()-downY));
          int sw=getResources().getDisplayMetrics().widthPixels;
          int sh=getResources().getDisplayMetrics().heightPixels;
          params.width=Math.min(newW,sw-20);
          params.height=Math.min(newH,sh-20);
          wm.updateViewLayout(root,params); return true;
      }
      return true;
    });

    root=box;
    int sw=getResources().getDisplayMetrics().widthPixels;
    params=new WindowManager.LayoutParams(
      Math.min((int)(sw*0.92f),720),
      Math.min((int)(getResources().getDisplayMetrics().heightPixels*0.72f),1100),
      Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
      PixelFormat.TRANSLUCENT);
    params.gravity=Gravity.TOP|Gravity.LEFT;
    params.x=Math.max(10,(sw-params.width)/2);
    params.y=80;
    wm=(WindowManager)getSystemService(WINDOW_SERVICE);
    wm.addView(root,params);
  }

  @Override public int onStartCommand(Intent i,int f,int s){return START_STICKY;}

  @Override public void onDestroy(){
    if(root!=null&&wm!=null)try{wm.removeView(root);}catch(Exception e){}
    super.onDestroy();
  }

  @Override public IBinder onBind(Intent i){return null;}
}
