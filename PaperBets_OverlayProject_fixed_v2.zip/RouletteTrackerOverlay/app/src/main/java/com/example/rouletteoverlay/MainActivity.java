package com.example.rouletteoverlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private Button overlayButton;
    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); requestNotification(); }
    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,28,28,28); root.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title=new TextView(this); title.setText("Paper Bets\n\nDisplay Over Apps"); title.setTextSize(24); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,0,1));
        overlayButton=new Button(this); overlayButton.setText("Display Over Apps / Popup ON-OFF"); root.addView(overlayButton,new LinearLayout.LayoutParams(-1,-2));
        TextView info=new TextView(this); info.setText("Popup ON করলে ছোট tracker অন্য অ্যাপের উপর দেখা যাবে। Popup টেনে সরানো ও নিচের ডান কোণা ধরে size পরিবর্তন করা যাবে।"); info.setPadding(0,24,0,0); root.addView(info);
        overlayButton.setOnClickListener(v -> toggleOverlay()); setContentView(root);
    }
    private void toggleOverlay(){
        if(!Settings.canDrawOverlays(this)){ startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); return; }
        Intent i=new Intent(this,OverlayService.class); i.setAction(OverlayService.ACTION_TOGGLE);
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
    }
    private void requestNotification(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42); }
}
