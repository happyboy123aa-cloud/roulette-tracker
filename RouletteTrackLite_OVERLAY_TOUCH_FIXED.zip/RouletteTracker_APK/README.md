# Roulette Tracker APK

Upload this whole folder to GitHub. The included GitHub Actions workflow builds `Roulette-Tracker.apk`.

## Popup controls
- Display Over Apps permission button
- Popup ON / OFF buttons
- Floating popup can be dragged anywhere
- Resize button changes popup size
- Minimize button collapses the popup to its title bar
- X button closes the popup without opening the app
