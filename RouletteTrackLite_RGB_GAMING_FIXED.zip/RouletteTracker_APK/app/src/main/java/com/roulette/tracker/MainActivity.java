package com.roulette.tracklite;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.util.AttributeSet;
import android.widget.Button;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private Button permission;
    private RgbFrameLayout rgbBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().setStatusBarColor(Color.rgb(3, 10, 18));
        getWindow().setNavigationBarColor(Color.BLACK);

        rgbBox = findViewById(R.id.rgbBox);
        permission = findViewById(R.id.permissionButton);
        Button on = findViewById(R.id.popupOn);
        Button off = findViewById(R.id.popupOff);

        permission.setOnClickListener(v -> openOverlaySettings());

        on.setOnClickListener(v -> startPopup());

        off.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Popup OFF", Toast.LENGTH_SHORT).show();
        });

        updatePermissionButton();
    }

    private void updatePermissionButton() {
        if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
            permission.setText("Display Over Apps: Allowed ✓");
        } else {
            permission.setText("Display Over Apps");
        }
    }

    private void openOverlaySettings() {
        try {
            Intent i = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }

    private void startPopup() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this,
                    "Please allow Display Over Apps permission first.",
                    Toast.LENGTH_LONG).show();
            openOverlaySettings();
            return;
        }

        Intent i = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        Toast.makeText(this, "Popup ON", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionButton();
    }

}
