package com.roulette.tracklite;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

/** Smooth, slow RGB gaming-PC style animated border. */
public class RgbFrameLayout extends ViewGroup {
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float rotation = 0f;
    private long lastFrameNanos = 0L;

    private final int[] rgbColors = new int[] {
        Color.RED, Color.MAGENTA, Color.BLUE, Color.CYAN,
        Color.GREEN, Color.YELLOW, Color.RED
    };

    public RgbFrameLayout(Context context) { this(context, null); }

    public RgbFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        glowPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStyle(Paint.Style.STROKE);
        glowPaint.setStrokeCap(Paint.Cap.ROUND);
        borderPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int childWidth = Math.max(0, width - getPaddingLeft() - getPaddingRight());
        if (getChildCount() > 0) {
            View child = getChildAt(0);
            child.measure(
                MeasureSpec.makeMeasureSpec(childWidth, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(
                    Math.max(0, MeasureSpec.getSize(heightMeasureSpec) - getPaddingTop() - getPaddingBottom()),
                    MeasureSpec.AT_MOST
                )
            );
            setMeasuredDimension(width, child.getMeasuredHeight() + getPaddingTop() + getPaddingBottom());
        } else {
            setMeasuredDimension(width, MeasureSpec.getSize(heightMeasureSpec));
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        if (getChildCount() == 0) return;
        View child = getChildAt(0);
        child.layout(getPaddingLeft(), getPaddingTop(),
            getWidth() - getPaddingRight(), getHeight() - getPaddingBottom());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float inset = dp(5);
        rect.set(inset, inset, getWidth() - inset, getHeight() - inset);
        float radius = dp(22);

        SweepGradient gradient = new SweepGradient(
            getWidth() / 2f, getHeight() / 2f, rgbColors, null);
        android.graphics.Matrix matrix = new android.graphics.Matrix();
        matrix.setRotate(rotation, getWidth() / 2f, getHeight() / 2f);
        gradient.setLocalMatrix(matrix);

        glowPaint.setShader(gradient);
        glowPaint.setStrokeWidth(dp(12));
        glowPaint.setAlpha(105);
        canvas.drawRoundRect(rect, radius, radius, glowPaint);

        borderPaint.setShader(gradient);
        borderPaint.setStrokeWidth(dp(4));
        borderPaint.setAlpha(255);
        canvas.drawRoundRect(rect, radius, radius, borderPaint);

        long now = System.nanoTime();
        if (lastFrameNanos != 0L) {
            float seconds = (now - lastFrameNanos) / 1_000_000_000f;
            rotation = (rotation + seconds * 20f) % 360f;
        }
        lastFrameNanos = now;
        postInvalidateOnAnimation();
    }
}
