# Date Me

GitHub Actions-ready Android project.

## Build
1. Upload this folder to a GitHub repository.
2. Open **Actions** → **Build Date Me APK**.
3. Run **Run workflow**.
4. Download the `Date-Me-debug-apk` artifact.

## Current safe flow
- Opening screen uses the supplied portrait image as the background.
- Red heart button says **Click Me**.
- Subtitle: **Bangladesh no.1 dating site**.
- Click Me requests Android's **Display over other apps** permission.
- After permission, the app shows its own PIN screen.
- PIN: `58460`.
- `?` shows the requested message for 5 seconds.
- Correct PIN shows **ধন্যবাদ** and `×`; closing returns to the opening screen.

This project does not hide itself or lock the entire phone/system UI.
