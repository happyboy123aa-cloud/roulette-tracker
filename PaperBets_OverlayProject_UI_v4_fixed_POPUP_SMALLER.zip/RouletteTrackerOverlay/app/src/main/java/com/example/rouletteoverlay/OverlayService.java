package com.example.rouletteoverlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    public static final String ACTION_TOGGLE = "toggle";
    public static final String ACTION_SHOW = "show";
    public static final String ACTION_HIDE = "hide";
    private static final String CHANNEL_ID = "paper_bets_overlay";

    private WindowManager wm;
    private View popup;
    private WindowManager.LayoutParams lp;
    private boolean showing = false;

    private int downX, downY, startX, startY, startW, startH;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(7, notification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_TOGGLE.equals(action)) {
                if (showing) hide();
                else show();
            } else if (ACTION_SHOW.equals(action)) {
                show();
            } else if (ACTION_HIDE.equals(action)) {
                hide();
            }
        }
        return START_STICKY;
    }

    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setContentTitle("Paper Bets")
                .setContentText("Popup overlay চালু আছে")
                .setSmallIcon(R.drawable.ic_launcher)
                .setOngoing(true)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID, "Paper Bets Overlay", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(c);
        }
    }

    private void show() {
        if (showing || !Settings.canDrawOverlays(this) || wm == null) return;

        FrameLayout box = new FrameLayout(this);
        box.setBackgroundColor(Color.argb(245, 25, 25, 25));

        WebView web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setVerticalScrollBarEnabled(true);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        web.setWebViewClient(new WebViewClient());
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setBuiltInZoomControls(false);
        web.getSettings().setDisplayZoomControls(false);
        web.loadUrl("file:///android_asset/index.html");
        box.addView(web, new FrameLayout.LayoutParams(-1, -1));

        TextView drag = control("↕", 18, Color.argb(190, 0, 0, 0));
        FrameLayout.LayoutParams dh = new FrameLayout.LayoutParams(
                dp(38), dp(38), Gravity.TOP | Gravity.START);
        box.addView(drag, dh);

        TextView close = control("×", 22, Color.argb(220, 180, 30, 30));
        FrameLayout.LayoutParams ch = new FrameLayout.LayoutParams(
                dp(36), dp(36), Gravity.TOP | Gravity.END);
        box.addView(close, ch);
        close.setOnClickListener(v -> hide());

        TextView resize = control("↘", 20, Color.argb(190, 0, 0, 0));
        FrameLayout.LayoutParams rh = new FrameLayout.LayoutParams(
                dp(42), dp(42), Gravity.BOTTOM | Gravity.END);
        box.addView(resize, rh);

        // NOT_FOCUSABLE: the overlay does not take keyboard/focus from the app underneath.
        // NOT_TOUCH_MODAL: touches outside the popup continue to the underlying app.
        // No FLAG_LAYOUT_NO_LIMITS: keeps the popup inside the usable screen area.
        lp = new WindowManager.LayoutParams(
                dp(300), dp(420),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(10);
        lp.y = dp(90);

        try {
            wm.addView(box, lp);
            popup = box;
            showing = true;
        } catch (Exception e) {
            popup = null;
            showing = false;
        }

        drag.setOnTouchListener(this::move);
        resize.setOnTouchListener(this::resize);
    }

    private TextView control(String text, int size, int background) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(background);
        return v;
    }

    private boolean move(View v, MotionEvent e) {
        if (lp == null || popup == null) return false;
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            downX = (int) e.getRawX();
            downY = (int) e.getRawY();
            startX = lp.x;
            startY = lp.y;
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_MOVE) {
            lp.x = startX + (int) e.getRawX() - downX;
            lp.y = startY + (int) e.getRawY() - downY;
            wm.updateViewLayout(popup, lp);
            return true;
        }
        return true;
    }

    private boolean resize(View v, MotionEvent e) {
        if (lp == null || popup == null) return false;
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            downX = (int) e.getRawX();
            downY = (int) e.getRawY();
            startW = lp.width;
            startH = lp.height;
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_MOVE) {
            lp.width = Math.max(dp(160), startW + (int) e.getRawX() - downX);
            lp.height = Math.max(dp(190), startH + (int) e.getRawY() - downY);
            wm.updateViewLayout(popup, lp);
            return true;
        }
        return true;
    }

    private void hide() {
        if (popup != null && wm != null) {
            try { wm.removeView(popup); } catch (Exception ignored) { }
            popup = null;
        }
        showing = false;
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        hide();
        super.onDestroy();
    }
}
