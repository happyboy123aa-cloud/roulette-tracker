# Roulette Tracker

Android project for the Roulette Tracker app.

## GitHub Actions
The repository contains `.github/workflows/build.yml`.
It uses Java 17 and Gradle 8.7, verifies that `settings.gradle` is at the repository root,
builds `:app:assembleDebug`, and uploads the debug APK as `Roulette Tracker APK`.

IMPORTANT: upload/extract the CONTENTS of this ZIP into the GitHub repository root.
Do not put the whole ZIP file inside the repository and expect Actions to find settings.gradle.
