package com.roulette.tracker;

import android.app.*;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    TrackerView tracker;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(29,34,38)); getWindow().setNavigationBarColor(Color.rgb(3,20,33)); tracker=new TrackerView(this); setContentView(tracker); }
}

class TrackerView extends View {
    Paint p=new Paint(3); Paint stroke=new Paint(3); float den; int W,H; int boxCount=12, room=12; boolean showRoom=false; ArrayList<Integer> history=new ArrayList<>(Arrays.asList(10,19,17,17,21,19,17,20,20));
    int bg=Color.rgb(3,20,33), panel=Color.rgb(5,28,45), border=Color.rgb(0,88,145), white=Color.WHITE, red=Color.rgb(238,8,38), black=Color.rgb(2,12,21), green=Color.rgb(0,174,83), blue=Color.rgb(11,88,190), sky=Color.rgb(12,166,232), brown=Color.rgb(171,81,23), tan=Color.rgb(220,157,101), yellow=Color.rgb(255,235,0);
    RectF r=new RectF();
    TrackerView(Context c){super(c); den=getResources().getDisplayMetrics().density; p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(2)); setFocusable(true);}
    float dp(float v){return v*den;} void fill(Canvas c,int color,float l,float t,float rr,float b,float rad){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRoundRect(l,t,rr,b,rad,rad,p);} void line(Canvas c,float x1,float y1,float x2,float y2,int color,float sw){stroke.setColor(color);stroke.setStrokeWidth(dp(sw));c.drawLine(x1,y1,x2,y2,stroke);}
    void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align a,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(dp(size));p.setTextAlign(a);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
    @Override protected void onDraw(Canvas c){super.onDraw(c); W=getWidth();H=getHeight(); c.drawColor(bg); float s=W/1024f; c.save(); c.scale(s,s); drawUI(c,1024,H/s); c.restore();}
    void drawUI(Canvas c,float w,float h){
        // header
        drawRouletteIcon(c,92,72,46); txt(c,"ROULETTE TRACKER",150,102,50,white,Paint.Align.LEFT,true); drawGear(c,963,88,25);
        // box number
        panel(c,30,180,994,278); txt(c,"Box Number",62,242,34,Color.rgb(205,219,235),Paint.Align.LEFT,true); fill(c,Color.TRANSPARENT,407,200,616,259,14); stroke.setColor(Color.rgb(20,82,128));stroke.setStrokeWidth(2);c.drawRoundRect(407,200,616,259,14,14,stroke); txt(c,""+boxCount,512,244,48,white,Paint.Align.CENTER,true);
        // roulette table
        panel(c,30,302,994,584); drawTable(c);
        // quick selection
        panel(c,30,607,994,786); txt(c,"দ্রুত ঘর নির্বাচন",60,659,37,white,Paint.Align.LEFT,true); float bx=53, by=686, bw=126, bh=77, gap=16; for(int n=9;n<=15;n++){int i=n-9; fill(c,n==boxCount?Color.TRANSPARENT:Color.rgb(7,37,58),bx+i*(bw+gap),by,bx+i*(bw+gap)+bw,by+bh,16); stroke.setColor(n==boxCount?yellow:Color.rgb(27,83,127));stroke.setStrokeWidth(dp(n==boxCount?3:2));c.drawRoundRect(bx+i*(bw+gap),by,bx+i*(bw+gap)+bw,by+bh,16,16,stroke); txt(c,""+n,bx+i*(bw+gap)+bw/2,739,34,white,Paint.Align.CENTER,true); }
        // room row
        panel(c,30,810,994,928); txt(c,"ঘর নাম্বার",60,884,34,white,Paint.Align.LEFT,true); fill(c,Color.rgb(4,29,47),241,832,426,908,15); stroke.setColor(Color.rgb(20,86,135));stroke.setStrokeWidth(2);c.drawRoundRect(241,832,426,908,15,15,stroke);txt(c,""+room,332,884,34,white,Paint.Align.CENTER,true);txt(c,"⌄",394,882,30,white,Paint.Align.CENTER,true);
        fill(c,Color.rgb(212,112,9),449,831,716,909,15); txt(c,"▣  ঘর নাম্বার",582,882,31,white,Paint.Align.CENTER,true);
        fill(c,red,734,831,975,909,15);txt(c,"▣  CLEAR ALL",855,882,29,white,Paint.Align.CENTER,true);
        // history
        panel(c,30,954,994,1394); txt(c,"History",60,1008,36,white,Paint.Align.LEFT,true); line(c,53,1028,971,1028,Color.rgb(8,76,119),2);
        txt(c,"NUM -",61,1079,30,white,Paint.Align.LEFT,true); drawHistoryNumbers(c,255,1079);
        line(c,53,1094,971,1094,Color.rgb(8,76,119),2); txt(c,"B/S -",61,1142,30,white,Paint.Align.LEFT,true); drawBoxes(c,253,1110,0);
        line(c,53,1160,971,1160,Color.rgb(8,76,119),2); txt(c,"E/O -",61,1208,30,white,Paint.Align.LEFT,true); drawBoxes(c,253,1176,1);
        line(c,53,1226,971,1226,Color.rgb(8,76,119),2); txt(c,"R/B -",61,1274,30,white,Paint.Align.LEFT,true); drawBoxes(c,253,1242,2);
        line(c,53,1292,971,1292,Color.rgb(8,76,119),2); txt(c,"DOZ -",61,1340,30,white,Paint.Align.LEFT,true); drawDoz(c,255,1340);
    }
    void panel(Canvas c,float l,float t,float rr,float b){fill(c,Color.TRANSPARENT,l,t,rr,b,22);stroke.setColor(border);stroke.setStrokeWidth(2);c.drawRoundRect(l,t,rr,b,22,22,stroke);}
    void drawRouletteIcon(Canvas c,float x,float y,float rad){p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(226,8,29));c.drawCircle(x,y,rad,p);stroke.setColor(white);stroke.setStrokeWidth(3);c.drawCircle(x,y,rad-4,stroke);p.setColor(Color.rgb(30,30,30));c.drawCircle(x,y,rad*0.63f,p);p.setColor(red);for(int i=0;i<10;i++){double a=i*Math.PI/5;c.drawCircle(x+(float)Math.cos(a)*rad*.42f,y+(float)Math.sin(a)*rad*.42f,rad*.09f,p);}p.setColor(white);Path q=new Path();q.moveTo(x,y-17);q.lineTo(x+6,y-3);q.lineTo(x+20,y);q.lineTo(x+6,y+4);q.lineTo(x,y+20);q.lineTo(x-5,y+5);q.lineTo(x-20,y);q.lineTo(x-5,y-4);q.close();c.drawPath(q,p);}
    void drawGear(Canvas c,float x,float y,float rr){stroke.setColor(white);stroke.setStrokeWidth(5);stroke.setStyle(Paint.Style.STROKE);c.drawCircle(x,y,18,stroke);c.drawCircle(x,y,7,stroke);for(int i=0;i<8;i++){double a=i*Math.PI/4; c.drawLine(x+(float)Math.cos(a)*20,y+(float)Math.sin(a)*20,x+(float)Math.cos(a)*27,y+(float)Math.sin(a)*27,stroke);}}
    void drawTable(Canvas c){float left=48, top=319, zeroW=75, cw=76, ch=75, gap=0; int[][] nums={{3,6,9,12,15,18,21,24,27,30,33,36},{2,5,8,11,14,17,20,23,26,29,32,35},{1,4,7,10,13,16,19,22,25,28,31,34}}; fill(c,green,left,top,left+zeroW,top+3*ch+2,14);txt(c,"0",left+zeroW/2,top+145,50,white,Paint.Align.CENTER,true); for(int row=0;row<3;row++){for(int col=0;col<12;col++){float x=133+col*76,y=top+row*85;int n=nums[row][col];int colr=(n%2==1)?red:black;fill(c,colr,x,y,x+64,y+72,12);stroke.setColor(Color.rgb(31,82,120));stroke.setStrokeWidth(1.5f);c.drawRoundRect(x,y,x+64,y+72,12,12,stroke);txt(c,""+n,x+32,y+46,29,white,Paint.Align.CENTER,true);}}}
    void drawHistoryNumbers(Canvas c,float x,float y){int start=Math.max(0,history.size()-10);for(int i=start;i<history.size();i++){txt(c,""+history.get(i),x+(i-start)*72,y,27,white,Paint.Align.CENTER,false);}}
    void drawBoxes(Canvas c,float x,float y,int type){int start=Math.max(0,history.size()-10);for(int i=start;i<history.size();i++){int n=history.get(i);String s="";int color=blue; if(type==0){s=(n==0?"B":(n>=1&&n<=18?"S":"B"));color=s.equals("S")?sky:blue;} else if(type==1){s=(n%2==0?"E":"O");color=s.equals("E")?brown:tan;} else {s=(n%2==1?"R":"B");color=s.equals("R")?red:black;}float xx=x+(i-start)*64;fill(c,color,xx,y,xx+49,y+48,8);txt(c,s,xx+24,y+34,23,white,Paint.Align.CENTER,true);}}
    void drawDoz(Canvas c,float x,float y){int start=Math.max(0,history.size()-10);for(int i=start;i<history.size();i++){int n=history.get(i);int d=n==0?0:((n-1)/12)+1;txt(c,""+d,x+(i-start)*64,y,25,white,Paint.Align.CENTER,false);}}
    @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float s=W/1024f,x=e.getX()/s,y=e.getY()/s;
        if(y>=686&&y<=765&&x>=53&&x<=972){int i=(int)((x-53)/142); if(i>=0&&i<7){boxCount=9+i;invalidate();return true;}}
        if(y>=831&&y<=909){if(x>=241&&x<=426){showRoomDialog();return true;} if(x>=734){history.clear();invalidate();return true;} if(x>=449&&x<=716){ if(!history.isEmpty()) history.remove(history.size()-1);invalidate();return true;}}
        if(y>=319&&y<=575&&x>=125){int col=(int)((x-133)/76),row=(int)((y-319)/85); if(col>=0&&col<12&&row>=0&&row<3){int[][] ns={{3,6,9,12,15,18,21,24,27,30,33,36},{2,5,8,11,14,17,20,23,26,29,32,35},{1,4,7,10,13,16,19,22,25,28,31,34}}; if(history.size()<boxCount)history.add(ns[row][col]);invalidate();return true;}}
        if(y>=319&&y<=575&&x<125){if(history.size()<boxCount)history.add(0);invalidate();return true;} return true;}
    void showRoomDialog(){final String[] items=new String[20];for(int i=0;i<20;i++)items[i]="ঘর "+(i+1); new AlertDialog.Builder(getContext()).setTitle("ঘর নাম্বার").setItems(items,(d,w)->{room=w+1;invalidate();}).show();}
}
