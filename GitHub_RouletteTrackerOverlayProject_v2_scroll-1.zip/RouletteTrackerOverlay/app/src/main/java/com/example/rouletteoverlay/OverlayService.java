package com.example.rouletteoverlay;

import android.app.*;import android.content.*;import android.graphics.Color;import android.graphics.PixelFormat;import android.os.*;import android.provider.Settings;import android.view.*;import android.webkit.WebView;import android.webkit.WebViewClient;import android.widget.*;import java.util.*;

public class OverlayService extends Service {
 public static final String ACTION_TOGGLE="toggle"; private WindowManager wm; private View popup; private WindowManager.LayoutParams lp; private int downX,downY,startX,startY,startW,startH; private boolean showing=false; private static final String CH="overlay";
 @Override public void onCreate(){super.onCreate();createChannel();startForeground(7,notification());wm=(WindowManager)getSystemService(WINDOW_SERVICE);}
 @Override public int onStartCommand(Intent i,int f,int id){if(ACTION_TOGGLE.equals(i.getAction())){if(showing)hide();else show();}return START_STICKY;}
 private Notification notification(){return new Notification.Builder(this,CH).setContentTitle("Roulette Tracker").setContentText("Popup overlay চালু আছে").setSmallIcon(com.example.rouletteoverlay.R.drawable.ic_launcher).setOngoing(true).build();}
 private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CH,"Overlay",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
 private void show(){if(showing||!Settings.canDrawOverlays(this))return; FrameLayout box=new FrameLayout(this);box.setBackgroundColor(Color.argb(235,25,25,25));
  WebView web=new WebView(this);web.setBackgroundColor(Color.TRANSPARENT);web.setWebViewClient(new WebViewClient());web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.loadUrl("file:///android_asset/index.html");box.addView(web,new FrameLayout.LayoutParams(-1,-1));
  TextView drag=new TextView(this);drag.setText("↕");drag.setTextColor(Color.WHITE);drag.setTextSize(18);drag.setGravity(Gravity.CENTER);drag.setBackgroundColor(Color.argb(180,0,0,0));FrameLayout.LayoutParams dh=new FrameLayout.LayoutParams(38,38,Gravity.TOP|Gravity.START);box.addView(drag,dh);
  TextView close=new TextView(this);close.setText("×");close.setTextColor(Color.WHITE);close.setTextSize(22);close.setGravity(Gravity.CENTER);close.setBackgroundColor(Color.argb(210,180,30,30));FrameLayout.LayoutParams ch=new FrameLayout.LayoutParams(34,34,Gravity.TOP|Gravity.END);box.addView(close,ch);close.setOnClickListener(v->hide());
  TextView resize=new TextView(this);resize.setText("↘");resize.setTextColor(Color.WHITE);resize.setTextSize(20);resize.setGravity(Gravity.CENTER);resize.setBackgroundColor(Color.argb(180,0,0,0));FrameLayout.LayoutParams rh=new FrameLayout.LayoutParams(42,42,Gravity.BOTTOM|Gravity.END);box.addView(resize,rh);
  lp=new WindowManager.LayoutParams(dp(260),dp(300),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.START;lp.x=20;lp.y=120;
  wm.addView(box,lp);popup=box;showing=true;
  drag.setOnTouchListener((v,e)->move(e));resize.setOnTouchListener((v,e)->resize(e));
 }
 private boolean move(MotionEvent e){if(e.getAction()==0){downX=(int)e.getRawX();downY=(int)e.getRawY();startX=lp.x;startY=lp.y;return true;}if(e.getAction()==2){lp.x=startX+(int)e.getRawX()-downX;lp.y=startY+(int)e.getRawY()-downY;wm.updateViewLayout(popup,lp);return true;}return true;}
 private boolean resize(MotionEvent e){if(e.getAction()==0){downX=(int)e.getRawX();downY=(int)e.getRawY();startW=lp.width;startH=lp.height;return true;}if(e.getAction()==2){lp.width=Math.max(dp(180),startW+(int)e.getRawX()-downX);lp.height=Math.max(dp(180),startH+(int)e.getRawY()-downY);wm.updateViewLayout(popup,lp);return true;}return true;}
 private void hide(){if(popup!=null){wm.removeView(popup);popup=null;}showing=false;}
 private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 @Override public IBinder onBind(Intent i){return null;}
 @Override public void onDestroy(){hide();super.onDestroy();}
}
