package com.roulette.tracklite;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

public class OverlayService extends Service {
    private WindowManager wm;
    private LinearLayout root, bar, body;
    private WebView webView;
    private WindowManager.LayoutParams params;
    private boolean minimized = false;
    private float downX, downY;
    private int startX, startY;
    private float resizeDownX, resizeDownY;
    private int startW, startH;
    private TextView title;
    private ImageButton minBtn, closeBtn, resizeBtn;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate() {
        super.onCreate();
        createNotification();
        if (Build.VERSION.SDK_INT >= 26) startForeground(7, notification());
        if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) showPopup(); else stopSelf();
    }

    private void createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("roulette_popup", "Roulette Tracker Popup", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    private Notification notification() {
        if (Build.VERSION.SDK_INT >= 26) return new Notification.Builder(this, "roulette_popup").setContentTitle("Roulette Tracker").setContentText("Popup is running").setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build();
        return new Notification.Builder(this).setContentTitle("Roulette Tracker").setContentText("Popup is running").setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build();
    }

    private GradientDrawable bg(int color, int stroke) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(8)); if (stroke != 0) g.setStroke(dp(1), stroke); return g;
    }

    private void showPopup() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(330), dp(420), type,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(12); params.y = dp(100);

        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(2),dp(2),dp(2),dp(2)); root.setBackground(bg(0xFF061625,0xFF174878));
        bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(7),0,dp(4),0); bar.setBackground(bg(0xFF0B2238,0));
        title = new TextView(this); title.setText("Roulette Tracker"); title.setTextColor(Color.WHITE); title.setTextSize(14); title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(34), 1));
        minBtn = btn("—"); resizeBtn = btn("↘"); closeBtn = btn("×");
        bar.addView(minBtn, new LinearLayout.LayoutParams(dp(34), dp(30))); bar.addView(resizeBtn,new LinearLayout.LayoutParams(dp(34),dp(30))); bar.addView(closeBtn,new LinearLayout.LayoutParams(dp(34),dp(30)));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(36)));

        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        webView = new WebView(this); WebSettings s = webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false); webView.setBackgroundColor(0xFF061625); webView.loadUrl("file:///android_asset/index.html");
        body.addView(webView, new LinearLayout.LayoutParams(-1,-1)); root.addView(body,new LinearLayout.LayoutParams(-1,0,1));

        closeBtn.setOnClickListener(v -> stopSelf());
        minBtn.setOnClickListener(v -> toggleMinimize());
        resizeBtn.setOnTouchListener((v,e) -> resizeTouch(e));
        bar.setOnTouchListener(this::dragTouch);
        wm.addView(root, params);
    }

    private ImageButton btn(String text) {
        ImageButton b = new ImageButton(this);
        b.setBackground(bg(0xFF0B2238,0xFF174878));
        b.setColorFilter(Color.WHITE);
        if (text.equals("×")) b.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        else if (text.equals("—")) b.setImageResource(android.R.drawable.ic_media_pause);
        else b.setImageResource(android.R.drawable.ic_menu_crop);
        return b;
    }

    private boolean dragTouch(View v, MotionEvent e) {
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; return true;
            case MotionEvent.ACTION_MOVE: params.x=startX+(int)(e.getRawX()-downX); params.y=startY+(int)(e.getRawY()-downY); wm.updateViewLayout(root,params); return true;
        }
        return true;
    }
    private boolean resizeTouch(MotionEvent e) {
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: resizeDownX=e.getRawX(); resizeDownY=e.getRawY(); startW=params.width; startH=params.height; return true;
            case MotionEvent.ACTION_MOVE: params.width=Math.max(dp(220),startW+(int)(e.getRawX()-resizeDownX)); params.height=Math.max(dp(180),startH+(int)(e.getRawY()-resizeDownY)); wm.updateViewLayout(root,params); return true;
        }
        return true;
    }
    private void toggleMinimize() {
        minimized=!minimized; body.setVisibility(minimized?View.GONE:View.VISIBLE); params.height=minimized?dp(38):dp(420); wm.updateViewLayout(root,params);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){ return START_STICKY; }
    @Override public void onDestroy(){ if(wm!=null && root!=null){ try{wm.removeView(root);}catch(Exception ignored){} } super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){ return null; }
}
