package com.roulette.tracker;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends android.app.Activity {
    private TextView permissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildControlScreen();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setMinHeight(dp(52));
        b.setPadding(dp(12), 0, dp(12), 0);
        return b;
    }

    private void buildControlScreen() {
        FrameLayout screen = new FrameLayout(this);

        ImageView background = new ImageView(this);
        background.setImageResource(R.drawable.app_background);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        background.setAlpha(1.0f);
        screen.addView(background, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(18), dp(30), dp(18), dp(20));
        root.setBackgroundColor(Color.TRANSPARENT);

        TextView title = new TextView(this);
        title.setText("ROULETTE TRACKER");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(55)));

        TextView subtitle = new TextView(this);
        subtitle.setText("Floating roulette tracker");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(35)));

        permissionStatus = new TextView(this);
        permissionStatus.setTextSize(14);
        permissionStatus.setGravity(Gravity.CENTER);
        permissionStatus.setPadding(0, dp(8), 0, dp(12));
        root.addView(permissionStatus, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));

        Button displayButton = makeButton("DISPLAY OVER APP");
        displayButton.setOnClickListener(v -> openOverlaySettings());
        root.addView(displayButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));

        addSpace(root, 10);

        Button popupOn = makeButton("POPUP ON");
        popupOn.setOnClickListener(v -> startOverlay());
        root.addView(popupOn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));

        addSpace(root, 10);

        Button popupOff = makeButton("POPUP OFF");
        popupOff.setOnClickListener(v -> stopOverlay());
        root.addView(popupOff, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));

        TextView help = new TextView(this);
        help.setText("\nDISPLAY OVER APP = permission\nPOPUP ON = popup চালু\nPOPUP OFF = popup বন্ধ\nPopup-এর × বাটন চাপলেও popup বন্ধ হবে");
        help.setTextColor(Color.rgb(150, 165, 180));
        help.setTextSize(13);
        help.setGravity(Gravity.CENTER);
        root.addView(help, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(130)));

        screen.addView(root, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(screen);
        updatePermissionStatus();
    }

    private void addSpace(LinearLayout root, int dp) {
        View space = new View(this);
        root.addView(space, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(dp)));
    }

    private void updatePermissionStatus() {
        if (permissionStatus == null) return;
        if (Settings.canDrawOverlays(this)) {
            permissionStatus.setText("● Display over app: ON");
            permissionStatus.setTextColor(Color.rgb(70, 210, 120));
        } else {
            permissionStatus.setText("● Display over app: OFF");
            permissionStatus.setTextColor(Color.rgb(255, 170, 80));
        }
    }

    private void openOverlaySettings() {
        try {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }

    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "আগে DISPLAY OVER APP চালু করুন", Toast.LENGTH_LONG).show();
            openOverlaySettings();
            return;
        }

        Intent serviceIntent = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        Toast.makeText(this, "Popup ON", Toast.LENGTH_SHORT).show();
    }

    private void stopOverlay() {
        stopService(new Intent(this, OverlayService.class));
        Toast.makeText(this, "Popup OFF", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatus();
    }
}
