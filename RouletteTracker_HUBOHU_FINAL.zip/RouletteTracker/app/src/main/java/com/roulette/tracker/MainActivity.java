package com.roulette.tracker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(16,20,24));

        TextView title = new TextView(this);
        title.setText("ROULETTE TRACKER");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("Floating roulette tracker\n\n1. Allow Display over other apps.\n2. Tap Start Overlay.\n3. Use the 9–15 quick room selection inside the tracker.");
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(16);
        info.setPadding(0, dp(24), 0, dp(24));
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button permission = new Button(this);
        permission.setText("DISPLAY OVER OTHER APPS");
        permission.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            }
        });
        root.addView(permission, new LinearLayout.LayoutParams(-1, dp(52)));

        Button start = new Button(this);
        start.setText("START OVERLAY");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Please allow Display over other apps first", Toast.LENGTH_LONG).show();
                return;
            }
            Intent i = new Intent(this, OverlayService.class);
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "Roulette Tracker started", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(52));
        sp.topMargin = dp(12);
        root.addView(start, sp);

        Button stop = new Button(this);
        stop.setText("STOP OVERLAY");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Roulette Tracker stopped", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, dp(52));
        stp.topMargin = dp(8);
        root.addView(stop, stp);

        setContentView(root);
    }
}
