# Roulette Tracker

Android app recreated from the supplied visual reference. The project intentionally uses a simple custom View and no third-party UI dependencies.

## GitHub Actions
The included `.github/workflows/build.yml` installs Java 17 and Gradle 8.9 directly, so a Gradle wrapper is not required. The workflow builds `app:assembleDebug` and uploads the APK as **Roulette Tracker**.
