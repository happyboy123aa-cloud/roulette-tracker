package com.roulette.tracklite;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.util.AttributeSet;
import android.widget.Button;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private Button permission;
    private RgbFrameLayout rgbBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().setStatusBarColor(Color.rgb(3, 10, 18));
        getWindow().setNavigationBarColor(Color.BLACK);

        rgbBox = findViewById(R.id.rgbBox);
        permission = findViewById(R.id.permissionButton);
        Button on = findViewById(R.id.popupOn);
        Button off = findViewById(R.id.popupOff);

        permission.setOnClickListener(v -> openOverlaySettings());

        on.setOnClickListener(v -> startPopup());

        off.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Popup OFF", Toast.LENGTH_SHORT).show();
        });

        updatePermissionButton();
    }

    private void updatePermissionButton() {
        if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
            permission.setText("Display Over Apps: Allowed ✓");
        } else {
            permission.setText("Display Over Apps");
        }
    }

    private void openOverlaySettings() {
        try {
            Intent i = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }

    private void startPopup() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this,
                    "Please allow Display Over Apps permission first.",
                    Toast.LENGTH_LONG).show();
            openOverlaySettings();
            return;
        }

        Intent i = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        Toast.makeText(this, "Popup ON", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionButton();
    }

    /**
     * Slow, continuously moving RGB border like a gaming-PC light strip.
     * The colors travel around the entire box rather than flashing abruptly.
     */
    public static class RgbFrameLayout extends ViewGroup {
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private float rotation = 0f;
        private long lastFrameNanos = 0L;

        private final int[] rgbColors = new int[] {
                Color.RED,
                Color.MAGENTA,
                Color.BLUE,
                Color.CYAN,
                Color.GREEN,
                Color.YELLOW,
                Color.RED
        };

        public RgbFrameLayout(android.content.Context context) {
            this(context, null);
        }

        public RgbFrameLayout(android.content.Context context, AttributeSet attrs) {
            super(context, attrs);
            setWillNotDraw(false);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);

            glowPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStyle(Paint.Style.STROKE);

            // A gentle glow around the moving RGB strip.
            glowPaint.setStrokeWidth(dp(9));
            glowPaint.setStrokeCap(Paint.Cap.ROUND);
            glowPaint.setAlpha(150);

            borderPaint.setStrokeWidth(dp(4));
            borderPaint.setStrokeCap(Paint.Cap.ROUND);
        }

        private float dp(float value) {
            return value * getResources().getDisplayMetrics().density;
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            int childWidth = Math.max(0, width - getPaddingLeft() - getPaddingRight());

            int childHeightSpec = MeasureSpec.makeMeasureSpec(
                    MeasureSpec.getSize(heightMeasureSpec),
                    MeasureSpec.getMode(heightMeasureSpec)
            );

            if (getChildCount() > 0) {
                View child = getChildAt(0);
                child.measure(
                        MeasureSpec.makeMeasureSpec(childWidth, MeasureSpec.EXACTLY),
                        childHeightSpec
                );
                int desiredHeight = child.getMeasuredHeight()
                        + getPaddingTop() + getPaddingBottom();
                setMeasuredDimension(width, desiredHeight);
            } else {
                setMeasuredDimension(width, MeasureSpec.getSize(heightMeasureSpec));
            }
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            if (getChildCount() == 0) return;
            View child = getChildAt(0);
            int left = getPaddingLeft();
            int top = getPaddingTop();
            int right = getWidth() - getPaddingRight();
            int bottom = getHeight() - getPaddingBottom();
            child.layout(left, top, right, bottom);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            float inset = dp(5);
            rect.set(inset, inset, getWidth() - inset, getHeight() - inset);
            float radius = dp(22);

            SweepGradient gradient = new SweepGradient(
                    getWidth() / 2f,
                    getHeight() / 2f,
                    rgbColors,
                    null
            );

            gradient.setLocalMatrix(
                    new android.graphics.Matrix() {{
                        setRotate(rotation, getWidth() / 2f, getHeight() / 2f);
                    }}
            );

            glowPaint.setShader(gradient);
            borderPaint.setShader(gradient);

            // Wide soft RGB glow.
            glowPaint.setStrokeWidth(dp(12));
            glowPaint.setAlpha(105);
            canvas.drawRoundRect(rect, radius, radius, glowPaint);

            // Crisp RGB light strip.
            borderPaint.setStrokeWidth(dp(4));
            borderPaint.setAlpha(255);
            canvas.drawRoundRect(rect, radius, radius, borderPaint);

            // Slow movement: one complete RGB trip in about 18 seconds.
            long now = System.nanoTime();
            if (lastFrameNanos != 0L) {
                float seconds = (now - lastFrameNanos) / 1_000_000_000f;
                rotation += seconds * 20f;
                if (rotation >= 360f) rotation -= 360f;
            }
            lastFrameNanos = now;

            postInvalidateOnAnimation();
        }
    }
}
