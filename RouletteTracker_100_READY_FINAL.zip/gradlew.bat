@echo off
setlocal

set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.7"
set "DIST_DIR=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin"
set "INSTALL_DIR=%DIST_DIR%\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%INSTALL_DIR%\bin\gradle.bat"
set "ZIP_FILE=%DIST_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
set "URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"

if not exist "%GRADLE_BIN%" (
  if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"
  if not exist "%ZIP_FILE%" (
    echo Downloading Gradle %GRADLE_VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
      "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP_FILE%'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "Expand-Archive -Force '%ZIP_FILE%' '%DIST_DIR%'"
  if errorlevel 1 exit /b 1
)

call "%GRADLE_BIN%" %*
endlocal
