# Roulette Tracker

Android floating Roulette Tracker app.

## GitHub Actions
Push the project to the `main` branch or run **Roulette Tracker APK** manually from
GitHub Actions. The workflow uses the Android SDK already provided by the GitHub
runner instead of the failing `android-actions/setup-android` step, then installs
API 35/build-tools 35.0.0 and builds `app-debug.apk`.

The APK is uploaded as the Actions artifact named `RouletteTracker-Floating-APK`.
