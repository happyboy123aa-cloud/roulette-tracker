package com.example.rouletteoverlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView overlayStatus;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(8, 8, 20));
        w.setNavigationBarColor(Color.rgb(4, 7, 20));
        buildUi();
        requestNotification();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);

        ImageView background = new ImageView(this);
        background.setImageResource(R.drawable.paper_bets_background);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(background, new FrameLayout.LayoutParams(-1, -1));

        // A subtle dark layer keeps the controls readable without changing the background image.
        View shade = new View(this);
        shade.setBackgroundColor(Color.argb(38, 0, 0, 20));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(18), dp(16), dp(12));

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.paper_bets_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(64), dp(64));
        header.addView(logo, logoLp);

        TextView title = new TextView(this);
        title.setText("Paper Bets");
        title.setTextColor(Color.WHITE);
        title.setTextSize(32);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(12), 0, dp(10), 0);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        overlayStatus = new TextView(this);
        overlayStatus.setText("●  Overlay\n    OFF");
        overlayStatus.setTextColor(Color.WHITE);
        overlayStatus.setTextSize(14);
        overlayStatus.setGravity(Gravity.CENTER);
        overlayStatus.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        overlayStatus.setPadding(dp(12), dp(7), dp(12), dp(7));
        overlayStatus.setBackground(round(Color.argb(205, 5, 9, 30), dp(18), Color.argb(130, 80, 100, 170), dp(1)));
        header.addView(overlayStatus, new LinearLayout.LayoutParams(dp(118), dp(58)));

        content.addView(header, new LinearLayout.LayoutParams(-1, dp(72)));

        // The three requested controls stay together at the bottom of the app content.
        SpaceFiller filler = new SpaceFiller(this);
        content.addView(filler, new LinearLayout.LayoutParams(1, 0, 1));

        LinearLayout buttonsPanel = new LinearLayout(this);
        buttonsPanel.setOrientation(LinearLayout.HORIZONTAL);
        buttonsPanel.setGravity(Gravity.CENTER);
        buttonsPanel.setPadding(dp(8), dp(10), dp(8), dp(10));
        buttonsPanel.setBackground(round(Color.argb(190, 5, 10, 35), dp(24), Color.argb(100, 70, 90, 160), dp(1)));

        Button display = actionButton("▣", "Display\nOver Apps", Color.rgb(0, 125, 255), Color.rgb(15, 35, 105));
        Button popupOn = actionButton("⊕", "Popup ON", Color.rgb(0, 235, 130), Color.rgb(5, 80, 65));
        Button popupOff = actionButton("⊗", "Popup OFF", Color.rgb(255, 35, 80), Color.rgb(100, 10, 35));

        buttonsPanel.addView(display, weightParams(1));
        buttonsPanel.addView(popupOn, weightParams(1));
        buttonsPanel.addView(popupOff, weightParams(1));

        content.addView(buttonsPanel, new LinearLayout.LayoutParams(-1, dp(108)));

        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        display.setOnClickListener(v -> openOverlayPermission());
        popupOn.setOnClickListener(v -> setPopup(true));
        popupOff.setOnClickListener(v -> setPopup(false));

        setContentView(root);
    }

    private Button actionButton(String icon, String text, int borderColor, int fillColor) {
        Button b = new Button(this);
        b.setText(icon + "\n" + text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setGravity(Gravity.CENTER);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(3), dp(3), dp(3), dp(3));
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setBackground(round(Color.argb(225, Color.red(fillColor), Color.green(fillColor), Color.blue(fillColor)), dp(20), borderColor, dp(2)));
        b.setElevation(dp(5));
        return b;
    }

    private LinearLayout.LayoutParams weightParams(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, weight);
        p.setMargins(dp(4), dp(2), dp(4), dp(2));
        return p;
    }

    private GradientDrawable round(int fill, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius);
        g.setStroke(strokeWidth, strokeColor);
        return g;
    }

    private void openOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } else {
            Toast.makeText(this, "Display Over Apps already enabled", Toast.LENGTH_SHORT).show();
        }
    }

    private void setPopup(boolean on) {
        if (!Settings.canDrawOverlays(this)) {
            openOverlayPermission();
            return;
        }

        Intent i = new Intent(this, OverlayService.class);
        i.setAction(on ? OverlayService.ACTION_SHOW : OverlayService.ACTION_HIDE);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);

        overlayStatus.setText(on ? "●  Overlay\n    ON" : "●  Overlay\n    OFF");
        overlayStatus.setTextColor(on ? Color.rgb(110, 255, 160) : Color.WHITE);
    }

    private void requestNotification() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 42);
        }
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static class SpaceFiller extends View {
        SpaceFiller(android.content.Context c) { super(c); }
    }
}
