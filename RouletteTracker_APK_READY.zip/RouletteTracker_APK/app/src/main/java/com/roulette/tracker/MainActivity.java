package com.roulette.tracker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setBackgroundColor(0xFF061625);
        webView.loadUrl("file:///android_asset/index.html");

        Button permission = findViewById(R.id.permissionButton);
        Button on = findViewById(R.id.popupOn);
        Button off = findViewById(R.id.popupOff);

        permission.setOnClickListener(v -> openOverlaySettings());
        on.setOnClickListener(v -> startPopup());
        off.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 55);
        }
    }

    private void openOverlaySettings() {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }
    }

    private void startPopup() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please allow Display Over Apps permission first.", Toast.LENGTH_LONG).show();
            openOverlaySettings();
            return;
        }
        Intent i = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        Toast.makeText(this, "Popup ON", Toast.LENGTH_SHORT).show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) {
            findViewById(R.id.permissionButton).setText("Display Over Apps: Allowed ✓");
        }
    }
}
