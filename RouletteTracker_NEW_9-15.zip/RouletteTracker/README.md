# Roulette Tracker

Fresh Android project for a floating roulette tracker.

## Included
- Roulette numbers 0–36
- Box number
- B/S, E/O, Colour and Dozen history
- Delete Last and Clear All
- Select **5 through 20** visible history boxes
- Saved history and selected limit using local storage
- Move and resize floating overlay
- Separate close button
- GitHub Actions debug APK build

## GitHub
Repository root must contain `settings.gradle`, `build.gradle`, `gradle.properties` and the `app` folder.
Then open **Actions → Roulette Tracker → Run workflow**.
