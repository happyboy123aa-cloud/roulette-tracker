package com.roulette.tracker;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.*;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private FrameLayout root;
    private WindowManager.LayoutParams params;
    private float downX, downY;
    private int startX, startY, startW, startH;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        createNotification();
        createOverlay();
    }

    private void createNotification() {
        final String channelId = "roulette_tracker";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(channelId, "Roulette Tracker", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channelId)
                : new Notification.Builder(this);
        b.setContentTitle("Roulette Tracker")
                .setContentText("Overlay is running")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true);
        startForeground(1001, b.build());
    }

    private void createOverlay() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.TRANSPARENT);

        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(16,20,24));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("file:///android_asset/roulette_tracker.html");
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        TextView dragBar = new TextView(this);
        dragBar.setText("  Roulette Tracker");
        dragBar.setTextColor(Color.WHITE);
        dragBar.setTextSize(15);
        dragBar.setGravity(Gravity.CENTER_VERTICAL);
        dragBar.setBackgroundColor(Color.rgb(34,34,34));
        dragBar.setPadding(dp(8), 0, dp(8), 0);
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(-1, dp(46), Gravity.TOP);
        root.addView(dragBar, barLp);

        TextView close = new TextView(this);
        close.setText("×");
        close.setTextColor(Color.WHITE);
        close.setTextSize(28);
        close.setGravity(Gravity.CENTER);
        close.setBackgroundColor(Color.rgb(180,45,56));
        close.setOnClickListener(v -> stopSelf());
        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(dp(48), dp(46), Gravity.TOP | Gravity.RIGHT);
        root.addView(close, closeLp);

        dragBar.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX(); downY = e.getRawY();
                    startX = params.x; startY = params.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = startX + (int)(e.getRawX() - downX);
                    params.y = startY + (int)(e.getRawY() - downY);
                    wm.updateViewLayout(root, params);
                    return true;
                default: return true;
            }
        });

        TextView resize = new TextView(this);
        resize.setText("↘");
        resize.setTextColor(Color.WHITE);
        resize.setTextSize(20);
        resize.setGravity(Gravity.CENTER);
        resize.setBackgroundColor(0xAA333333);
        FrameLayout.LayoutParams resizeLp = new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.BOTTOM | Gravity.RIGHT);
        root.addView(resize, resizeLp);
        resize.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX(); downY = e.getRawY(); startW = params.width; startH = params.height; return true;
                case MotionEvent.ACTION_MOVE:
                    int sw = getResources().getDisplayMetrics().widthPixels;
                    int sh = getResources().getDisplayMetrics().heightPixels;
                    params.width = Math.max(dp(300), Math.min(sw - dp(16), startW + (int)(e.getRawX() - downX)));
                    params.height = Math.max(dp(280), Math.min(sh - dp(80), startH + (int)(e.getRawY() - downY)));
                    wm.updateViewLayout(root, params); return true;
                default: return true;
            }
        });

        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;
        int width = Math.min((int)(sw * 0.94f), dp(720));
        int height = Math.min((int)(sh * 0.72f), dp(1100));
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(width, height, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = Math.max(dp(8), (sw - width) / 2);
        params.y = dp(70);
        wm.addView(root, params);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        if (root != null && wm != null) try { wm.removeView(root); } catch (Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
