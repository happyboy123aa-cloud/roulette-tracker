package com.example.rouletteoverlay;

import android.app.*;import android.content.*;import android.graphics.PixelFormat;import android.os.*;import android.provider.Settings;import android.view.*;import android.webkit.*;import android.widget.*;

public class OverlayService extends Service {
  WindowManager wm; View root; int lastX,lastY; float downX,downY;
  @Override public void onCreate(){super.onCreate();
    String ch="roulette_overlay"; if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(ch,"Roulette Overlay",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);}
    Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ch):new Notification.Builder(this); nb.setContentTitle("Roulette Overlay").setContentText("Overlay is running").setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true); startForeground(7,nb.build());
    WebView w=new WebView(this); w.setBackgroundColor(0xFF101010); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.loadUrl("file:///android_asset/roulette_tracker.html");
    LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); TextView bar=new TextView(this); bar.setText("  Roulette Overlay     ×"); bar.setTextSize(16); bar.setTextColor(0xFFFFFFFF); bar.setBackgroundColor(0xFF222222); bar.setPadding(12,10,12,10);
    bar.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getRawX();downY=e.getRawY();lastX=params.x;lastY=params.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=lastX+(int)(e.getRawX()-downX);params.y=lastY+(int)(e.getRawY()-downY);wm.updateViewLayout(root,params);return true;}return true;});
    bar.setOnClickListener(v->stopSelf()); box.addView(bar); box.addView(w,new LinearLayout.LayoutParams(-1,0,1)); root=box;
    params=new WindowManager.LayoutParams((int)(Math.min(getResources().getDisplayMetrics().widthPixels*0.92,720)),WindowManager.LayoutParams.WRAP_CONTENT,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT); params.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;params.y=80; wm=(WindowManager)getSystemService(WINDOW_SERVICE);wm.addView(root,params);
  }
  WindowManager.LayoutParams params;
  @Override public int onStartCommand(Intent i,int f,int s){return START_STICKY;}
  @Override public void onDestroy(){if(root!=null&&wm!=null)try{wm.removeView(root);}catch(Exception e){}super.onDestroy();}
  @Override public android.os.IBinder onBind(Intent i){return null;}
}
