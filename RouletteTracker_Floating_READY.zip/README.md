# Roulette Tracker Floating Overlay

This Android project wraps the supplied Roulette Tracker HTML in a WebView and runs it as a movable/resizable overlay.

## GitHub
Upload the CONTENTS of this folder to the repository root, including `.github`.

Then open:
Actions -> Roulette Tracker APK -> Run workflow

The generated APK is under the workflow run's Artifacts as:
RouletteTracker-Floating-APK
