package com.roulette.tracker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

public class OverlayService extends Service {
    private static final String CHANNEL_ID = "roulette_overlay";
    private static final int NOTIFICATION_ID = 77;

    private WindowManager wm;
    private FrameLayout root;
    private WindowManager.LayoutParams params;
    private WebView webView;
    private int lastX, lastY;
    private float downRawX, downRawY;
    private int startWidth, startHeight;
    private boolean resizing = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        showOverlay();
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Roulette Tracker")
                .setContentText("Floating overlay চলছে")
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Roulette Tracker Overlay",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    private void showOverlay() {
        if (!Settings.canDrawOverlays(this) || root != null) return;

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.TRANSPARENT);

        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDefaultTextEncodingName("UTF-8");
        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.loadUrl("file:///android_asset/index.html");

        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        // Invisible top drag bar: drag the popup from the very top area.
        View dragBar = new View(this);
        dragBar.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams dragLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(34)
        );
        dragLp.gravity = Gravity.TOP;
        root.addView(dragBar, dragLp);

        dragBar.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                lastX = params.x;
                lastY = params.y;
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = lastX + (int)(event.getRawX() - downRawX);
                params.y = lastY + (int)(event.getRawY() - downRawY);
                wm.updateViewLayout(root, params);
                return true;
            }
            return true;
        });

        // Bottom-right resize handle.
        TextView resize = new TextView(this);
        resize.setText("↘");
        resize.setTextColor(Color.WHITE);
        resize.setTextSize(18);
        resize.setGravity(Gravity.CENTER);
        resize.setBackgroundColor(Color.argb(170, 25, 45, 66));
        FrameLayout.LayoutParams resizeLp = new FrameLayout.LayoutParams(dp(34), dp(34));
        resizeLp.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        root.addView(resize, resizeLp);

        resize.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    resizing = true;
                    startWidth = params.width;
                    startHeight = params.height;
                    downRawX = event.getRawX();
                    downRawY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (resizing) {
                        int nw = Math.max(dp(260), startWidth + (int)(event.getRawX() - downRawX));
                        int nh = Math.max(dp(180), startHeight + (int)(event.getRawY() - downRawY));
                        params.width = nw;
                        params.height = nh;
                        wm.updateViewLayout(root, params);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    resizing = false;
                    return true;
            }
            return true;
        });

        params = new WindowManager.LayoutParams(
                dp(380),
                dp(620),
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(8);
        params.y = dp(70);

        wm.addView(root, params);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (root == null) showOverlay();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (root != null && wm != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
